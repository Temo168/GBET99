External provider adapters belong here.

Before production:
- connect a licensed/approved payment provider
- connect an appropriate KYC/identity provider
- connect an approved geolocation service where required
- add AML/sanctions screening
- implement webhook signature verification
- reconcile provider records against the internal ledger

Do not put provider secrets in source control.
