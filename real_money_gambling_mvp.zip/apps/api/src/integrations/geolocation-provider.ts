export interface GeolocationProvider {
  verifyAccess(input: {
    ipAddress: string;
    jurisdiction: string;
  }): Promise<{ allowed: boolean; reason?: string }>;
}
