export interface PaymentProvider {
  createDeposit(input: {
    amountMinor: bigint;
    currency: string;
    customerId: string;
  }): Promise<{ providerReference: string; checkoutUrl?: string }>;

  createWithdrawal(input: {
    amountMinor: bigint;
    currency: string;
    customerId: string;
  }): Promise<{ providerReference: string }>;

  verifyWebhook(
    payload: Buffer,
    signature: string
  ): Promise<unknown>;
}
