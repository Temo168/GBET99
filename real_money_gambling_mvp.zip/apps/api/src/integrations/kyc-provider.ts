export interface KycProvider {
  createVerification(input: {
    userId: string;
    email: string;
  }): Promise<{ reference: string }>;

  getVerificationStatus(reference: string): Promise<{
    status: "PENDING" | "VERIFIED" | "REJECTED";
  }>;
}
