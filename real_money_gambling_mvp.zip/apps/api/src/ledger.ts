import { PrismaClient } from "@prisma/client";

export type Posting = {
  accountId: string;
  amountMinor: bigint;
};

export function assertBalanced(postings: Posting[]) {
  const total = postings.reduce((sum, p) => sum + p.amountMinor, 0n);
  if (total !== 0n) throw new Error("Unbalanced ledger transaction");
}

export async function postLedger(
  prisma: PrismaClient,
  input: {
    idempotencyKey: string;
    userId?: string;
    type: "DEPOSIT" | "WITHDRAWAL" | "WAGER" | "WIN" | "REFUND" | "BONUS" | "ADJUSTMENT";
    currency: string;
    postings: Posting[];
    amountMinor: bigint;
  }
) {
  assertBalanced(input.postings);

  return prisma.$transaction(async tx => {
    const existing = await tx.transaction.findUnique({
      where: { idempotencyKey: input.idempotencyKey }
    });
    if (existing) return existing;

    const transaction = await tx.transaction.create({
      data: {
        idempotencyKey: input.idempotencyKey,
        userId: input.userId,
        type: input.type,
        status: "COMPLETED",
        currency: input.currency,
        amountMinor: input.amountMinor
      }
    });

    await tx.ledgerEntry.createMany({
      data: input.postings.map(p => ({
        transactionId: transaction.id,
        accountId: p.accountId,
        amountMinor: p.amountMinor
      }))
    });

    return transaction;
  });
}
