import Fastify from "fastify";
import { z } from "zod";
import { prisma } from "./db.js";
import { generateOutcome, calculatePayout } from "./games/roulette.js";

const app = Fastify({ logger: true });

app.get("/health", async () => ({ ok: true }));

app.get("/api/v1/games", async () => {
  return prisma.game.findMany({ where: { enabled: true } });
});

app.post("/api/v1/games/:gameId/rounds", async (request, reply) => {
  const bodySchema = z.object({
    userId: z.string().uuid(),
    wagerMinor: z.string().regex(/^\d+$/),
    currency: z.string().length(3),
    bet: z.object({
      type: z.enum(["RED", "BLACK", "EVEN", "ODD", "NUMBER"]),
      number: z.number().int().min(0).max(36).optional()
    })
  });

  const body = bodySchema.parse(request.body);
  const wager = BigInt(body.wagerMinor);

  const user = await prisma.user.findUnique({
    where: { id: body.userId },
    include: { selfExclusion: true }
  });

  if (!user || user.status !== "ACTIVE" || user.kycStatus !== "VERIFIED") {
    return reply.code(403).send({ error: "ACCOUNT_NOT_ELIGIBLE" });
  }

  if (user.selfExclusion &&
      (user.selfExclusion.permanent ||
       !user.selfExclusion.endsAt ||
       user.selfExclusion.endsAt > new Date())) {
    return reply.code(403).send({ error: "SELF_EXCLUDED" });
  }

  const game = await prisma.game.findUnique({
    where: { id: request.params && (request.params as any).gameId }
  });

  if (!game?.enabled || game.slug !== "roulette") {
    return reply.code(404).send({ error: "GAME_NOT_AVAILABLE" });
  }

  // IMPORTANT: A production implementation must resolve the user's
  // actual ledger balance, enforce limits, and settle the wager atomically.
  // This scaffold intentionally does not connect an external payment
  // provider or permit real-money operation.

  const outcome = generateOutcome();
  const payout = calculatePayout(body.bet, outcome, wager);

  const round = await prisma.gameRound.create({
    data: {
      gameId: game.id,
      userId: user.id,
      wagerMinor: wager,
      payoutMinor: payout,
      currency: body.currency,
      status: "SETTLED",
      outcome: outcome as any,
      settledAt: new Date()
    }
  });

  return {
    roundId: round.id,
    status: round.status,
    wagerMinor: round.wagerMinor.toString(),
    payoutMinor: round.payoutMinor.toString(),
    outcome
  };
});

app.listen({
  port: Number(process.env.API_PORT ?? 4000),
  host: "0.0.0.0"
});
