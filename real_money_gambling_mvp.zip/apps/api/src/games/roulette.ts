import { randomInt } from "node:crypto";

export type RouletteBet = {
  type: "RED" | "BLACK" | "EVEN" | "ODD" | "NUMBER";
  number?: number;
};

export type RouletteOutcome = {
  number: number;
  color: "RED" | "BLACK" | "GREEN";
};

const red = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);

export function generateOutcome(): RouletteOutcome {
  const number = randomInt(0, 37);
  return {
    number,
    color: number === 0 ? "GREEN" : red.has(number) ? "RED" : "BLACK"
  };
}

export function calculatePayout(bet: RouletteBet, outcome: RouletteOutcome, wager: bigint) {
  let wins = false;
  let multiplier = 0n;

  if (bet.type === "RED" || bet.type === "BLACK") {
    wins = outcome.color === bet.type;
    multiplier = 2n;
  } else if (bet.type === "EVEN" || bet.type === "ODD") {
    wins = outcome.number !== 0 &&
      (bet.type === "EVEN" ? outcome.number % 2 === 0 : outcome.number % 2 !== 0);
    multiplier = 2n;
  } else if (bet.type === "NUMBER" && bet.number === outcome.number) {
    wins = true;
    multiplier = 36n;
  }

  return wins ? wager * multiplier : 0n;
}
