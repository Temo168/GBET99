import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <header className="border-b border-white/10 px-6 py-4 flex justify-between">
        <div className="font-black text-xl">PLAYZONE</div>
        <nav className="flex gap-5 text-sm">
          <Link href="/casino">Casino</Link>
          <Link href="/wallet">Wallet</Link>
          <Link href="/account">Account</Link>
        </nav>
      </header>

      <section className="px-6 py-16 max-w-6xl mx-auto">
        <h1 className="text-5xl font-black">Casino & Games</h1>
        <p className="mt-4 text-slate-300 max-w-xl">
          A modern dark gaming-lobby interface inspired by common sportsbook
          and casino layouts, without copying another operator's branding.
        </p>

        <div className="mt-10 grid md:grid-cols-3 gap-5">
          <Link href="/casino/roulette"
            className="rounded-2xl bg-slate-900 border border-white/10 p-6 hover:bg-slate-800">
            <h2 className="text-2xl font-bold">Roulette</h2>
            <p className="text-slate-400 mt-2">Play the demo game.</p>
          </Link>
        </div>
      </section>
    </main>
  );
}
