"use client";

import { useState } from "react";

export default function RoulettePage() {
  const [bet, setBet] = useState("RED");
  const [result, setResult] = useState<any>(null);

  async function play() {
    // Replace with authenticated user ID/session handling.
    const userId = prompt("Development user ID");
    if (!userId) return;

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000"}/api/v1/games/ROULETTE_ID/rounds`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          wagerMinor: "100",
          currency: "USD",
          bet: { type: bet }
        })
      }
    );

    setResult(await response.json());
  }

  return (
    <main className="min-h-screen bg-slate-950 text-white p-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-black">Roulette</h1>

        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-3">
          {["RED", "BLACK", "EVEN", "ODD"].map(option => (
            <button
              key={option}
              onClick={() => setBet(option)}
              className={`p-4 rounded-xl border ${
                bet === option
                  ? "border-white bg-white/20"
                  : "border-white/10 bg-slate-900"
              }`}
            >
              {option}
            </button>
          ))}
        </div>

        <button
          onClick={play}
          className="mt-8 w-full rounded-xl bg-emerald-500 text-black font-bold py-4"
        >
          Spin
        </button>

        {result && (
          <pre className="mt-8 bg-slate-900 rounded-xl p-5 overflow-auto">
            {JSON.stringify(result, null, 2)}
          </pre>
        )}
      </div>
    </main>
  );
}
